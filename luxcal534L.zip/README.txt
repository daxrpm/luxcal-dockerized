LuxCal Web Based Event Calendar

Highlights

This new LuxCal version 5.1.1 includes interesting new features, improved technical issues and bug-fixes.
Most important new features / improvements:
• A new Day Marking feature has been added. Users with at least manager rights can "mark" days in the calendar with a specified color and a text an the top of the day cell.
• A simple Side Panel info text editor has been added to the calendar, to create/edit info texts for to be displayed in the side panel.
• On the admin's Settings page a free-format text message can be specified, which will be added as a paragraph to the end of reminder email messages.
• If the PHP multi-byte extension is installed, the printing of PDF files supports UTF-8 text (European fonts, Cyrillic fonts, Greek fonts, Asian fonts, etc.)

Hereafter you will find a full summary of all changes since LuxCal version 5.1.0.

New features/Improvements
• A new Day Marking feature has been added. Users with at least manager rights can "mark" days in the calendar. In year and month view, and in the mini calendars the top line of the day cell is shown with the specified background color and optionally a short text in a specified color.
• When in the PHP installation multi-byte support is installed ("mbstring"), the printing of PDF files supports UTF-8 text (European fonts, Cyrillic fonts, Greek fonts, Asian fonts, etc.). If multi-byte support is not installed, the PDF print feature uses the Helvetica font with cp1252 (Western Europe) encoding, as in earlier calendar versions.
• Via the configuration files, it is now possible for PDF printouts to specify the page size (A4 or Letter).
• For the allowed HTML tags in the event title the <center>-tag, which is not supported in HTML5, has been removed and the <br>-tag has been added, so that users can split event titles over multiple lines by inserting a <br>-tag.
• A simple Side Panel info text editor has been added to the calendar. When logged in with at least Manager rights the side menu shows an entry "Info Text Editor".	The editor page with instructions, can produce backup copies of the file sidepanel/info.txt with a date/time stamp and can create/edit the file sidepanel/info.txt with the side panel info messages.
• For the info text in the side panel in Month, Week and Day view it is now possible, in the line preceding the message, to specify the exact start date and end date during which the message should be displayed (~m.d-m.d~).
• It is now possible to show a side panel with one or more of the side panel items on each of the calendar view pages. On the Settings page, in the Views section, for each side panel item it can be specified in which view it should be shown.
• On the admin's Settings page, in the section Reminders, a free-format text message can be specified, which will be added as a paragraph to the end of reminder email messages. HTML-tags are allowed in the text message.
• When enabled on the Settings page, users with sufficient rights will get an option in the side menu to print a Birthday Calendar to a PDF file.
• The Upcoming Events page, the Changed Events page and the Search page have become more responsive and consequently better viewable on narrow display devices.
• The stand-alone mini-calendar (display0) and the mini calendar in the optional sidebar in month, week and day view now shows the full day in the category color for events which have "Day color" set. When days have been marked (see new Day Marker feature above) these days will also be marked in the stand-alone mini calendar and the mini calendar in the optional sidebar. The optional Day Marker text will be shown when hovering the day cell top line.
• Month view and the mini calendars have now an extra set of arrows in the header to skip to the previous and next year.
• The "drag time" feature in week and day view has been improved. The dragging is more reactive now and accidental dragging above the start drag time is not possible anymore.
• The symbols to toggle between the reduced and full size of the event window have been replaced by the more common ▼ and ▲ symbols.
• The width of all date and time input fields is now expressed in 'em', which makes the field width better fit and uniform in different browsers.
• On the Upcoming Events page the padding has been reduced to compact the list of events.
• On the settings page the time interval and height of the time slots in day and week view belong together and therefore have been put on the same line. Cosmetic change.
• URL links in events were always opening in a new (blank) page/tab. It is now possible to place the prefix 'S:' in front of the URL, which makes the URL link open in the same (Self) page/tab.
• If the event title in the left column of the gantt chart is long or contains <br>-tags and uses more than one line, the table cell can now be scrolled via the mouse wheel.
• When on the categories page sorting the categories on name, the sorting has been changed from case-sensitive to case-insensitive.
• The restore function on the calendar's database page has been improved. It is now possible to import .sql backup files from earlier calendar versions, starting with calendar version 2.7.2. When importing a database backup file from an earlier calendar version, the database will automatically be upgraded to the current calendar version. In addition, it is now also possible to import .sql backup files from both MySQL and SQLite type databases. However, when importing a backup file from a different database type, the calendar version of the source and destination calendar must be the same.
• In month view a 2-pixel left and right margin have been added to the events in the day cells.
• The tools in the !luxcal-toolbox folder, which can be handy when experiencing problems, have been improved. The cron.php tool used to periodically run multiple applications via one single cronjob on your server, has been made more flexible. It can now be run either once a day, or each hour. When run each hour, for each script to be started, the start hour can be specified. In addition, for each script it can be specified if a confirmation email should be sent and if the result should be logged.

Technical issues
• The function "array_key_exists" has been replaced by function "isset". PHP 8 compatibility.
• The function "implode" without first parameter (glue) has been given an empty string as first parameter. PHP 8 compatibility.
• The checkSettings function now also saves the checked settings to the database.
• Simplification: on the search, changes and upcoming pages a list of events is now put in one table, rather than putting each individual event in its own table.
• HTML syntax error in the search results repaired. The <dir>-tag should be <div> (2x).
• Some headers have been added to the download script to ensure compatibility with all browsers. In addition, the user can now see the file size when the download starts.
• To the headers for PHP and SMTP mail "Return-path" has been added. Some mail servers seem to prefer this. The header for SMTP mail had a redundant (double) CRLF just before the "$message". One CRLF removed.
• On the Settings page, the "Restore last user selections" and the expiry days have been moved to one and the same line. Cosmetic change.
• When the install and upgrade scripts are started with URL parameter ?phpinfo, the PHPinfo() function will be started and the script will be aborted. This can help to solve problems when the calendar installation fails.
• Various changes in the toolbox.js file. JavaScript code simplified. Support for IE11 dropped. Redundant "return false" statements removed. The winFit function has been simplified. For the pop functions the name 'popobj' replaced by 'popElm' (naming confusion), all strings converted to 'template literals' (enclosed by back ticks).
• The PDF classes to print upcoming events to a PDF file, have been revised and made more flexible. The precision with which the elements are positioned on the page has improved. 
• The fpdf class used to produce PDF files has been upgraded from version 1.8.2 to 1.8.3.

Bug fixes
• When upgrading from LuxCal versions 2.7 - 3.2 in the settings table the setting dateFormat was not converted from the old format '1', '2' or 3 to 'd-m-y', 'm-d-y' or 'y-m-d' respectively.
• Upgrading from calendar versions 4.5 and 4.6 produced an SQL error, because in the upgrade function the old multi-field sub-categories were not converted to the new flexible single field sub-categories format.
• Email links did not work in email reminder messages. The use of email links in the event description and extra fields has been completely reviewed and simplified, without loss of functionality.
• On the Changes page PHP messages "Notice: Undefined index: sc1 in retrievc.php on line 148" were displayed.
• Email addresses with a 1-character local part (e.g. j@mail.com) were flagged as invalid. They are however valid and should be accepted.
• When in the Changes view a different From date was selected, on narrow displays the To date was partially hidden by the list with changes.
• When in the options panel one single category was selected, for which repeat was set, and thereafter a new event was created, eventform0 was mistakenly opened with PHP errors (tx1, tx2 and tx3 undefined). Solved.
